
def funcion():
    while True:
        try:
            a = int(input("Teclea un número: "))
            return a
            break
        except ValueError:
            print("Debe ser número entero")

print(funcion())

