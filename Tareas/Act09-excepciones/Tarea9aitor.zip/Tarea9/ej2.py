def esEntero():
    a = int(input("Teclea un número"))
    print(a)
    b = str(a)
    if b.isnumeric() == False:
        raise ValueError

while True:
    try:
        esEntero()
        break
    except ValueError:
        print("Debe ser un número entero")