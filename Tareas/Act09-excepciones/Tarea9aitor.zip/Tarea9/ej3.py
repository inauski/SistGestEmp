class A(Exception):
    valor = 0
    def __init__(self, valor):
        self.valor = valor

    def __str__(self):
        return "Opción que no es A-B-M"


while True:
    try:
        a = input('Ingresa A (Altas - B(Bajas) - M(Modificaciones)):')
        a = a.lower()
        if(a == 'a' or a == 'b' or a == 'm'):
            print(a.upper())
            break
        else:
            raise A(a)
    except A as e:
        print (e)