class Calculadora(object):
    num1 = float
    num2 = float
    cont_calculos = 0
    def __init__(self,num1,num2):
        self.num1 = num1
        self.num2 = num2
        Calculadora.cont_calculos += 1
    def sumar(self):
        return self.num1+self.num2

    def restar(self):
        return self.num1 - self.num2

    def multiplicar(self):
        return self.num1 * self.num2

    def dividir(self):
        return self.num1 / self.num2

    def leer_numero(prompt):
        try:
            a = prompt
            float(a)
            return True
        except ValueError:
            return False

    def leer_signo(prompt):
        a = prompt
        if (a == "+" or a == "-" or a == "*" or a == "/"):
            return True
        else:
            return False




terminar = float(input("Primer operando (0:Terminar): "))
clase = Calculadora
while (terminar != 0.0):
    op = float(input("Segundo operando (0:Terminar): "))
    #while signol == False:
    signo = input("signo (+,-,*,/): ")
    if clase.leer_signo(signo):
        if signo == "+":
            print("%.2f" % Calculadora(terminar,op).sumar())
        elif signo == "-":
            print("%.2f" % Calculadora(terminar, op).restar())
        elif signo == "*":
            print("%.2f" % Calculadora(terminar, op).multiplicar())
        elif signo == "/":
            try:
                print(Calculadora(terminar, op).dividir())
            except ZeroDivisionError:
                print("Divisor es 0")
    z = False
    while z == False:
        try:
            terminar = float(input("Primer operando (0:Terminar): "))
            z = True
        except ValueError:
            z = False
print("Total operaciones %d" % Calculadora.cont_calculos)
