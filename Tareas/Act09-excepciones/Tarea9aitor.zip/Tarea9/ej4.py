def factorial(x,n):
    if(n > 0):
        x=factorial(x,n-1)
        x=x*n
    else:
        x=1
    return x

class Factorial(object):
    n = int
    def __init__(self, numero):
        self.n = numero

    def factorial (self):
        if self.n == 0:
            return 1
        else:
            m = self.n - 1
            return self.n*Factorial(m).factorial()

try:
    a = int(input("Escribe un número entero mayor que 0: "))
    print("Factorial:",Factorial(a).factorial())
except ValueError:
    print("Debe ser un número entero")
except RecursionError:
    print("Valor negativo. El número debe ser mayor o igual a 0")