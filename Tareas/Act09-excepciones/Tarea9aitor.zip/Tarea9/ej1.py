while True:
    try:
        resp = int(input("Teclea un número"))
        print(resp)
        break
    except ValueError:
        print("Debe ser un número entero")






