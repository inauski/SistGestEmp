#Excepciones

while True:
    try:
        x = int(input("Escriba un número"))
        break
    except ValueError:
        print("No es válido. Intente de nuevo")

# raise levanta el error de ejecución. Propaga el error de ejecucion a la funcion que lo ha llamado

def function_raise():
    try:
        raise NameError("Hola, este es el mensaje de raise")
    except NameError:
        print("Voló una excepción")
        raise
try: #Captura el error de ejecución. El error genérico es Exception.
    function_raise()
    print("fin")
except NameError as er:
    print(er)


#Ver: assert, raise, try-else-catch-finally