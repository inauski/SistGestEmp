# -*- coding: cp1252 -*-
import math

print("int(exp(2 * log(3))) =", int(math.exp(2 * math.log(3))))
print("round(4*sin(3 * pi / 2))= ", round(4 * math.sin(3 * math.pi / 2)))
print("abs(log10(.01) * sqrt(25))=", abs(math.log10(.01) * math.sqrt(25)))
print("round(3.21123 * log10(1000), 3)=", round(3.21123 * math.log10(1000), 3))
