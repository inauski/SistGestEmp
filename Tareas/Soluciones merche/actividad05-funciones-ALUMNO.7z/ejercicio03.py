# -*- coding: utf8 -*-
import misfunciones.matematicas as mismates

# from misfunciones.matematicas import *

print("1. Área de cuadrado")
print("2. Área de triángulo")
op = mismates.leer_numero("Teclea una opción (1-2:) ")

if op == '1':
    lado=mismates.leer_numero ("Lado de cuadrado:")
    ente,decimal,string=mismates.convertidor(lado)
    area=mismates.area_cuadrado(decimal)
    print ("Área del cuadrado es: %2f" % area )
elif op=='2':
    base = mismates.leer_numero("Base:")
    altura = mismates.leer_numero("Altura:")
    ente, decimal, string = mismates.convertidor(base)
    base=decimal
    ente, decimal, string = mismates.convertidor(altura)
    altura = decimal
    area = mismates.area_triangulo(base,altura)
    print("Área del triángulo es: %.2f" % area)


