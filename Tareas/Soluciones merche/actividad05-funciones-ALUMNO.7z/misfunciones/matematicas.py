# -*- coding: utf8 -*-
def area_triangulo(base,altura):
    """Dado la base y  altura de un triángulo, calcula y devuelve su área."""
    return (base*altura)/2
def area_cuadrado(lado):
    """Dado el lado de un cuadrado calcula y devuelve su área"""
    return lado*lado
def convertidor(numero):
    """Dado un número devuelve el número en entero, real y string"""
    return (int(numero),float(numero),str(numero))
def leer_numero(mensaje):
    return input(mensaje)


