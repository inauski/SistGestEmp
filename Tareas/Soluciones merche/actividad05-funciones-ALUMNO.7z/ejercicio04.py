# -*- coding: utf-8 -*
suma = lambda op1, op2: op1 + op2
resta= lambda op1, op2: op1 - op2
multiplicar = lambda op1, op2: op1 * op2
dividir = lambda op1, op2: op1 / op2

num1 = float(input("Teclea un número:"))
num2 = float(input("Teclea un número:"))
print("Suma %.2f + %.2f: %.2f" % (num1, num2, suma(num1, num2)))
print("Resta %.2f - %.2f: %.2f" % (num1, num2, resta(num1, num2)))
print('Multiplicación %.2f * %.2f: %.2f' % (num1, num2, multiplicar(num1, num2)))
print("División %.2f / %.2f: %.2f" % (num1, num2, dividir(num1, num2)))

