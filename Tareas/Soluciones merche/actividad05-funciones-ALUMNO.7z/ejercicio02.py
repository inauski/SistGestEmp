# -*- coding: utf-8 -*-
import sys

print("MÁXIMO número entero %s" % sys.maxsize )
print("VERSIÓN API %s" % sys.api_version)
print("COPIYRIGHT %s" % sys.copyright)
print("FLOAT STYLE %s" % sys.float_repr_style)
print("JUEGO DE CARACTERES USADOS %s" % sys.getdefaultencoding())

