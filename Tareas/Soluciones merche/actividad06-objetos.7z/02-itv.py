# -*- coding: utf-8 -*


class CocheItv(object):
    def __init__(self, matricula, anio):

        if matricula[0:4].isdigit() and matricula[4]=="-" and matricula[5:8].isalpha():
            self.matricula = matricula
            self.anio = anio
        else:
            raise ValueError("Matrícula incorrecta:" + matricula)
    def SiguienteItv(self):
        return self.anio + 4

def main():
    try:
        matricula=input("Matrícula (0000-sss): ")
        anio=int(input("Año: "))
        c1 = CocheItv(matricula, anio)

        print("El coche con matrícula %s del año %d la siguiente ITV la tiene en el año %d" % \
        (c1.matricula, c1.anio,c1.SiguienteItv()))

    except ValueError as e:
        print(e)
    except Exception as e:
        print(e)


main()
