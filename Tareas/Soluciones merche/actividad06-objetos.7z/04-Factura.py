class Factura (object):

    def __init__(self, base_imponible,iva,descuento):
       self.base_imponible = base_imponible;
       self.iva = iva;
       self.descuento = descuento;

    def base_con_descuento(self):
        return self.base_imponible - self.base_imponible * self.descuento / 100

    def total_iva_incluido(self):
        return self.base_con_descuento()+(self.base_con_descuento()*self.iva/100)
def main():
    print("-- FACTURA --");

    baseImponible = float(input("Introduzca BASE IMPONIBLE: "));

    discount = input("¿ Hay descuento? s/n");
    if discount.lower() == "s":
        descu = 10;
    elif discount.lower() == "n":
        descu = 0;
    else:
        print("Debe escribir 's' para SI o 'n' para NO")
        exit()

    iv = input("¿ Que tipo de IVA se aplicará: General(g) o Reducido(r)?")
    if iv.lower() == "g":
        iva = 21;
    elif iv.lower() == "r":
        iva = 6;
    else:
        print("Debe introducir o 'G' para General o 'R' para Reducido")
        exit()

    factura = Factura(baseImponible, descu, iva)
    print("La factura con BASE IMPONIBLE {}".format(baseImponible))
    print("Tiene un {} % de descuento y quedaria {}".format(descu, factura.base_con_descuento()))
    print("Se aplica un {} % de IVA y su valor es {}".format(iva, factura.total_iva_incluido()))
main()