# -*- coding: utf-8 -*
class Prestamo(object):
    def __init__(self, capital=0, tipointeres=0, anios=0):
        self.capital = float(capital)
        self.tipointeres = float(tipointeres)
        self.anios = float(anios)

    def CalcularInteres(self):
        return self.capital * self.tipointeres / 100 * self.anios

def main():
    try:
        print("PRÉSTAMO 1")
        p1 = Prestamo(float(12000), float(5), float(30))
        total_intereses = p1.CalcularInteres()
        print("Capital: %.2f" % p1.capital)
        print("Interés: %.2f" % p1.tipointeres)
        print("Años: %d" % p1.anios)
        print("Total intereses: %.2f" % total_intereses)

        print("PRÉSTAMO 2")
        capital = float(input("Capital: "))
        interes = float(input("Tipo de interés %: "))
        tiempo = float(input("Años: "))
        p2 = Prestamo(capital, interes, tiempo)
        total_intereses = p2.CalcularInteres()
        print("Capital: %2f" % p2.capital)
        print("Interés: %2f" % p2.tipointeres)
        print("Años: %d" % p2.anios)
        print("Total intereses: %.2f" % total_intereses)
    except Exception as e:
        print("ERROR", e)


main()
