# -*- coding: utf8 -*-
# Hay dos atributos de Clase, y mediante unos métodos acumula y cuenta en dichos atributos cada vez que se crea una instancia

class Alumno:
    'Clase para alumnos'
    numalumnos = 0
    sumanotas = 0

    def __init__(self, nombre, nota):
        self.nombre = nombre
        self.nota = nota
        Alumno.numalumnos += 1
        Alumno.sumanotas += nota

    def mostrarNombreNota(self):
        return (self.nombre, self.nota)

    def mostrarNumAlumnos(self):
        return (Alumno.numalumnos)

    def mostrarSumaNotas(self):
        return (Alumno.sumanotas)

    def mostrarNotaMedia(self):
        if Alumno.numalumnos > 0:
            return (Alumno.sumanotas / Alumno.numalumnos)
        else:
            return ("Sin alumnos")


def main():
    alumno1 = Alumno("Maria", 8)
    alumno2 = Alumno("Carlos", 6)
    print(alumno1.nombre)  # María Atributo de instancia
    print(alumno1.nota)  # 8 Atributo de instancia
    alumno1.nombre = "Carmela"
    print(Alumno.numalumnos)  # 2 Atributo de clase
    print(Alumno.sumanotas)  # 14 Atributo de clase
    print(alumno1.mostrarNombreNota())  # ('Carmen', 8)
    print(alumno2.mostrarNombreNota())  # ('Carlos', 6)
    # del alumno1.nombre  borra el atributo nombre de alumno1
    # print(alumno1.mostrarNombreNota()) error al borrar el atributo

if __name__ == "__main__":
    main()
