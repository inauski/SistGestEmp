# -*- coding: utf8 -*-

class Cuadrado():
    """Clase que guarda el lado de un cuadrado y calcula su área"""
    def __init__(self,lado=0):
        self.l=lado
    def area_cuadrado(self):
        return self.l*self.l
class Rectangulo():
    def __init__(self,base=0,altura=0):
        self.b=base
        self.h=altura
    def area_rectangulo(self):
        return (self.b * self.h)/2
def main():
    print("Cálculo de áreas")
    print("1.Cuadrado")
    print("2.Rectángulo")
    op=int(input("Teclea una opción (1-2)"))
    if op==1:
        lado= int(input ("Lado del cuadrado: "))
        cua=Cuadrado(lado)
        print ("El área del cuadrado es %d" % cua.area_cuadrado() )
    elif op == 2:
        base= int(input ("Base: "))
        altura= int(input("Altura: "))
        rec = Rectangulo(base,altura)
        print("El área del rectángulo es %d.2" % rec.area_rectangulo() )

if __name__ == '__main__':
    main()

